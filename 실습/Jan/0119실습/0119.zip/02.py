num = list(map(int,input().split(",")))
print(sum(num))