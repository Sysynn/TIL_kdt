i = 0
while i <= 10:
    i = i + 1
    print(i)
"""
1
2
3
4
5
6
7
8
9
10
11

"""