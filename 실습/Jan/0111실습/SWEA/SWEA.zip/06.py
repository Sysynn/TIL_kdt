# 더블더블

num = int(input())
for i in range(0, num + 1):
    print(2 ** i, end = ' ')