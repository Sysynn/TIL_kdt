for element in range(-2, 10, 2):
    print(element, end=" ")
    
"""
-2, 0, 2, 4, 6, 8
"""