a = int(input())
b = list(range(1,a + 1))
print(sum(b))