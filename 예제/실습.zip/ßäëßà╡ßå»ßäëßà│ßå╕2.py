food = input("좋아하는 음식을 입력해주세요 > ")
print("좋아하는 음식 : ", food)