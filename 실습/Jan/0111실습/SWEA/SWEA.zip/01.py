# 신문 헤드라인
a = input().upper()

print(a)