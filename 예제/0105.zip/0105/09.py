try:
    number = 1
    if number == 1
        print(number)
    
    
except:
    print("에러가 발생했습니다.")
    print("에러의 원인은 무엇인가요?")


"""
# if number == 1 뒤에 : 가 빠져있습니다
""" 