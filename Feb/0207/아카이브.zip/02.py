# 7568 덩치
# T = int(input())
# height = []
# weight = []
# for t in range(T):
#     a, b = list(map(int,input().split()))
#     height.append(a)
#     weight.append(b)
