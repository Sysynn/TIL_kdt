# 1251 단어 나누기

word = input()
for i in word:
    