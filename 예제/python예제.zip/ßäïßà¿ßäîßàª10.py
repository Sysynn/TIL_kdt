age = int(input("너의 나이는?"))

print("올해 나이 : ", age) # input값
print("내년 나이 : ", age + 1) # input 값 + 1