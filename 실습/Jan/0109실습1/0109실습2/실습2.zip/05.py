a, b, c = input('전화번호를 입력하세요 >').split()
print(f"{a}-{b}-{c}")