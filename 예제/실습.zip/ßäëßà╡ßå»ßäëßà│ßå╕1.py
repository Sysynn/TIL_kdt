number = int(input("숫자를 입력해주세요 > "))
print(number + 10)

str = input("좋아하는 음식을 입력해주세요 > ")
print(str(input))