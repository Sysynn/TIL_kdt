string = input("문자열을 입력해주세요 > ")
number = input("숫자를 입력해주세요 > ")
print(str(string)*int(number))