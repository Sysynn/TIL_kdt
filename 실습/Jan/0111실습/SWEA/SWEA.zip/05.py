N = input()
n = list(map(int,N))
total = (sum(n))
print(total)