i = 0
while True:
    print(i) 
    if i > 10:
        break
    i = i + 1
    
"""
0
1
2
3
4
5
6
7
8
9
10
11

"""