first = str(input("첫 번쨰 문장을 입력해주세요 > "))
second = str(input("두 번째 문장을 입력해주세요 > "))
print(first+second)